# coding=utf-8
#   PROGRAM INFO.
#       Name: xml-file parsing.
#       Author: Vicente Fajardo.
#       This program gets all the combinatories ro run for a specific program.
#       Version: 1.0 (Completely stable).
#       Parameters:
#       --inputFile A GU file (format xml).
#       --outputFile File to save the results.

#   LIBRARIES.
from optparse import OptionParser

#       PARAMETERS DEFINITION.
parser = OptionParser()
parser.add_option("--outputFile", dest="outputFile")
(options, args) = parser.parse_args()

if len(args) > 0:
    parser.error("None parameters indicated.")
    sys.exit(1)

#   MAIN PROGRAM.
combinations = [["True"], ["False"]]
for i in range(0, 10):
  temp_comb = []
  for comb in combinations:
    comb1 = comb + ["True"]
    comb2 = comb + ["False"]
    temp_comb = temp_comb + [comb1, comb2]
  combinations = temp_comb

cmd_options = ["--excludeStopWords", "--excludeSymbols", "--endsConLow", "--endsNumber", "--dash_sym", "--greek_let", "--is_miRNA", "--all_supper", "--bigrams", "--trigrams", "--emb_digit"]

with open(str(options.outputFile), 'w') as oFile:
  for combination in combinations:
    cmd = "python3.4 training-validation-v1-more_func.py --inputPath /home/vfajardo/storage/4th_semester/BEI_II/Natural_Language_Processing/Clonning_GitHub_repositorie/conditional-random-fields/data-sets --trainingFile training-data-set-70.txt --testFile test-data-set-30.txt --outputPath /home/vfajardo/storage/4th_semester/BEI_II/Natural_Language_Processing/Clonning_GitHub_repositorie/conditional-random-fields "
    for boool, cmd_opt in zip(combination, cmd_options):
      cmd = cmd + " " + cmd_opt + " " + boool
    oFile.write(cmd + "\n")